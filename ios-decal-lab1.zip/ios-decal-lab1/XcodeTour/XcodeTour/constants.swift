//
//  constants.swift
//  XcodeTour
//
//  Created by Akilesh Bapu on 1/31/17.
//  Copyright © 2017 org.iosdecal. All rights reserved.
//

import Foundation

var recovery1 = 1
var recovery2 = 100
var recovery3 = 1000
var recovery4 = 10000
var recovery5 = 25000
var recovery6 = 50000
var recovery7 = 100000
var recovery8 = 200000
var recovery9 = 500000
var recovery10 = 1000000
var recovery11 = 1250000
var recovery12 = 1500000
var recovery13 = 2000000
var recovery14 = 5000000
